# Windows Subsystem for Linux Recommender

The **Remote - WSL recommender extension** adds commands to open a folder or workspace located in the [Windows Subsystem for Linux](https://docs.microsoft.com/en-us/windows/wsl). It will help installing the [Windows Subsystem for Linux](https://docs.microsoft.com/en-us/windows/wsl) and the [Remote WSL extension](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-wsl).

This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.
